import { Component, OnInit } from '@angular/core';
import { ReviewService } from '../components/review.service';
import { Review } from '../components/model/Review';
import { AuthenticateService } from '../components/authenticate.service';

@Component({
  selector: 'app-my-reviews',
  templateUrl: './my-reviews.component.html',
  styleUrls: ['./my-reviews.component.css']
})

export class MyReviewsComponent implements OnInit {
  
  
  constructor(public reviewService:ReviewService,public authService:AuthenticateService) {
    this.reviewService.getReview(this.authService.currentUser.id).subscribe((res: Review[]) => {
      if (res) {
        this.reviewService.reviews=res
        console.log( this.reviewService.reviews)
      }

     
    })
   
   }

  ngOnInit() {
  }

  

}




