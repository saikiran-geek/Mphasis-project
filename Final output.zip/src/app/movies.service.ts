import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Movie } from './components/model/Movie';
import { Review } from './components/model/Review';


const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  nowShowing: Movie[]
  comingSoon: Movie[]
  mostPopular: Movie[]
  movie:Movie
  allReviews:Review[]

  constructor(public http: HttpClient) {

  }

  getNowShowing() {
    return this.http.get<Movie[]>('http://172.18.218.111:8876/moviereview/movies/now-showing/all', httpOptions)
  }

  getComingSoon() {
    return this.http.get<Movie[]>('http://172.18.218.111:8876/moviereview/movies/coming-soon/all', httpOptions)
  }

  getMostPopular() {
    return this.http.get<Movie[]>('http://172.18.218.111:8876/moviereview/movies/most-popular/all', httpOptions)
  }

  getMovieDetails(id: number) {
    return this.http.get<Movie>('http://172.18.218.111:8876/moviereview/movies/details/' + id, httpOptions)
  }
  getAllReviews(movieId:number){
    return this.http.get('http://172.18.218.111:8876/moviereview/reviews/search/' + movieId, httpOptions)
  }
}
