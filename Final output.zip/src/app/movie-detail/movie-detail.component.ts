import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Movie } from '../components/model/Movie';
import { Review } from '../components/model/Review';
import { MoviesService } from '../movies.service';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.component.html',
  styleUrls: ['./movie-detail.component.css']
})
export class MovieDetailComponent implements OnInit {

  movie: Movie

  constructor(public router: ActivatedRoute, public moviesService: MoviesService) {
    this.movie = new Movie()
    moviesService.getMovieDetails(parseInt(router.snapshot.paramMap.get('id'))).subscribe(res => {
      this.movie = res
      this.moviesService.movie=res
    })
    this.moviesService.getAllReviews(parseInt(router.snapshot.paramMap.get('id'))).subscribe((res: Review[]) => {
      if (res) {
        this.moviesService.allReviews=res
        console.log( this.moviesService.allReviews)
      }

     
    })
   
  }
  ngOnInit() {

  }

}
