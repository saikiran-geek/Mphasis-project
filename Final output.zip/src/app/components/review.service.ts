import { Injectable } from '@angular/core';
import { Review } from './model/Review';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticateService } from './authenticate.service';
const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class ReviewService {
  
  reviews: Review[]
  
  constructor(public http: HttpClient) { }

  addReview(review: Review) {
    return this.http.post('http://172.18.218.111:8876/moviereview/reviews/save', review, httpOptions)
  }
  getReview(id:number){
    return this.http.get('http://172.18.218.111:8876/moviereview/reviews/search/users/' + id, httpOptions)
  }
  

}
