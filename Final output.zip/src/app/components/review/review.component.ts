import { Component, OnInit } from '@angular/core';
import { Review } from '../model/Review';
import { AuthenticateService } from '../authenticate.service';
import { ReviewService } from '../review.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {

  review: Review
  successFlag: boolean

  constructor(public authService: AuthenticateService, public reviewService: ReviewService, public route: ActivatedRoute) {
    this.review = new Review()
    this.successFlag = false
  }

  ngOnInit() {
  }

  addReview(reviewForm) {
    this.successFlag = false
    this.review.mfk = parseInt(this.route.snapshot.paramMap.get('id'))
    this.review.ufk = this.authService.currentUser.id
    this.review.reviewId = 0
    this.reviewService.addReview(this.review).subscribe((res: Review) => {
      reviewForm.form.markAsPristine()
      this.review = new Review()
      if (res)
        this.successFlag = true
    })
  }
}


