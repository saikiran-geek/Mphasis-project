// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Movie } from '../model/Movie';




// const httpOptions = {
//   headers: new HttpHeaders({
//     'Authorization': 'someToken'
//   }),
//   withCredentials: true
// };

// @Component({
//   selector: 'app-moviereview',
//   templateUrl: './moviereview.component.html',
//   styleUrls: ['./moviereview.component.css']
// })

// export class MoviereviewComponent implements OnInit {

//   id: string
//   movie: Movie
//   popular: Popular
//   topmovies: Topmovies

//   constructor(public router: ActivatedRoute, public http: HttpClient) {

//   }

//   ngOnInit() {
//     this.id = this.router.snapshot.paramMap.get('id')
//     this.http.get<Movie>('http://172.18.218.111:8876/moviereview/movies/' + this.id, httpOptions)
//       .subscribe(res => {
//         this.movie = res
//       })

//     this.id = this.router.snapshot.paramMap.get('id')
//     this.http.get<Popular>('http://172.18.218.111:8876/moviereview/mostpopulars/' + this.id, httpOptions)
//       .subscribe(res => {
//         this.popular = res
//       })

//     this.id = this.router.snapshot.paramMap.get('id')
//     this.http.get<Topmovies>('http://172.18.218.111:8876/moviereview/toprated/' + this.id, httpOptions)
//       .subscribe(res => {
//         this.topmovies = res
//       })
//   }

// }
