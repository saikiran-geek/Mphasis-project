import { Component, OnInit } from '@angular/core';
import { MoviesService } from 'src/app/movies.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  constructor(public moviesService: MoviesService) { }

  ngOnInit() {
    this.getNowShowing()
  }

  getNowShowing() {
    this.moviesService.getNowShowing().subscribe(res => {
      // console.log(res)
      this.moviesService.nowShowing = res
    })
  }

  getComingSoon() {
    this.moviesService.getComingSoon().subscribe(res => {
      // console.log(res)
      this.moviesService.comingSoon = res
    })
  }

  getMostPopular() {
    this.moviesService.getMostPopular().subscribe(res => {
      // console.log(res)
      this.moviesService.mostPopular = res
    })
  }

}
